''' Handling the data io '''
'''Build the input and output vocabulary and translate words of sentences into index of vocabulary'''
import argparse
import torch
import Constants
import random

def read_instances_from_file(inst_file, max_sent_len, keep_case):
    ''' Convert file into word seq lists and vocab '''

    word_insts = []
    trimmed_sent_count = 0
    with open(inst_file,'rb') as f:
        for sent in f:
            if not keep_case:
                sent = sent.lower()
            words = sent.split()
            if len(words) > max_sent_len:
                trimmed_sent_count += 1
            word_inst = words[:max_sent_len]
            if word_inst:
                word_insts += [[Constants.BOS_WORD] + word_inst + [Constants.EOS_WORD]]
            else:
                word_insts += [None]
    print('[Info] Get {} instances from {}'.format(len(word_insts), inst_file))
    if trimmed_sent_count > 0:
        print('[Warning] {} instances are trimmed to the max sentence length {}.'
              .format(trimmed_sent_count, max_sent_len))
    return word_insts

def build_vocab_idx(word_insts, min_word_count):
    ''' Trim vocab by number of occurence '''
    full_vocab = set(w for sent in word_insts for w in sent)
    print('[Info] Original Vocabulary size =', len(full_vocab))
    word2idx = {
        Constants.BOS_WORD: Constants.BOS,
        Constants.EOS_WORD: Constants.EOS,
        Constants.PAD_WORD: Constants.PAD,
        Constants.UNK_WORD: Constants.UNK,
        Constants.SRCSEP_WORD: Constants.SRCSEP,
        Constants.TGTSEP_WORD: Constants.TGTSEP}
    word_count = {w: 0 for w in full_vocab}
    for sent in word_insts:
        for word in sent:
            word_count[word] += 1
    ignored_word_count = 0
    for word, count in word_count.items():
        if word not in word2idx:
            if count > min_word_count:
                word2idx[word] = len(word2idx)
            else:
                ignored_word_count += 1
    print('[Info] Trimmed vocabulary size = {},'.format(len(word2idx)),
          'each with minimum occurrence = {}'.format(min_word_count))
    print("[Info] Ignored word count = {}".format(ignored_word_count))
    return word2idx

def convert_instance_to_idx_seq(word_insts, word2idx):
    ''' Mapping words to idx sequence. '''
    return [[word2idx.get(w, Constants.UNK) for w in s] for s in word_insts]

def main():
    ''' Main function '''

    parser = argparse.ArgumentParser()
    parser.add_argument('-train_src', required=True)
    parser.add_argument('-train_tgt', required=True)
    parser.add_argument('-valid_src', required=True)
    parser.add_argument('-valid_tgt', required=True)
    parser.add_argument('-save_data', required=True)
    parser.add_argument('-max_len', '--max_word_seq_len', type=int, default=50)
    parser.add_argument('-min_word_count', type=int, default=5)
    parser.add_argument('-keep_case', action='store_true')
    parser.add_argument('-share_vocab', action='store_true')
    parser.add_argument('-vocab', default=None)

    max_len = max_word_seq_len = 140
    min_word_count = 0
    keep_case = True
    share_vocab = False
    vocab = None 
    dataset_select = False

    max_token_seq_len = max_word_seq_len + 2 # include the <s> and </s>

    if dataset_select:
        dataset_src = './xrdata/auction/auctionxml/auction_preprocess.xml'
        dataset_tgt = './xrdata/auction/auctionn3/auction_preprocess.n3'
    else:
        dataset_src = './xrdata/mondial/mondialxml/merge.xml'
        dataset_tgt = './xrdata/mondial/mondialn3/pre_mondial.n3'

    file_dataset_src = open(dataset_src,'rb')
    file_dataset_tgt = open(dataset_tgt,'rb')
    text_lines_src = file_dataset_src.readlines()
    text_lines_tgt = file_dataset_tgt.readlines()
    rand_src_tgt = list(zip(text_lines_src,text_lines_tgt))
    random.shuffle(rand_src_tgt) 
    text_lines_src,text_lines_tgt = zip(*rand_src_tgt)
    text_lines_src = list(text_lines_src)
    text_lines_tgt = list(text_lines_tgt)
    len_src = len(text_lines_src)
    for i in range(len_src):
        if i/len_src<0.8:
            with open('./xrdata/train/src.xml','ab') as file_train_src:
                file_train_src.write(text_lines_src[i])
            with open('./xrdata/train/tgt.n3','ab') as file_train_tgt:
                file_train_tgt.write(text_lines_tgt[i])
        else:
            with open('./xrdata/test/src.xml','ab') as file_test_src:
                file_test_src.write(text_lines_src[i])
            with open('./xrdata/test/tgt.n3','ab') as file_test_tgt:
                file_test_tgt.write(text_lines_tgt[i])
    train_src = './xrdata/train/src.xml'
    train_tgt = './xrdata/train/tgt.n3'
    # valid_src = './data/validation/val.en'
    # valid_tgt = './data/validation/val.de'
    test_src = './xrdata/test/src.xml'
    test_tgt = './xrdata/test/tgt.n3'

    # Whole set
    dataset_src_word_insts = read_instances_from_file(
        dataset_src, max_word_seq_len, keep_case)
    dataset_tgt_word_insts = read_instances_from_file(
        dataset_tgt, max_word_seq_len, keep_case)

    if len(dataset_src_word_insts) != len(dataset_tgt_word_insts):
        print('[Warning] The whole dataset instance count is not equal.')
        min_inst_count = min(len(dataset_src_word_insts), len(dataset_tgt_word_insts))
        dataset_src_word_insts = dataset_src_word_insts[:min_inst_count]
        dataset_tgt_word_insts = dataset_tgt_word_insts[:min_inst_count]
    #- Remove empty instances
    dataset_src_word_insts, dataset_tgt_word_insts = list(zip(*[
        (s, t) for s, t in zip(dataset_src_word_insts, dataset_tgt_word_insts) if s and t]))

    # Training set
    train_src_word_insts = read_instances_from_file(
        train_src, max_word_seq_len, keep_case)
    train_tgt_word_insts = read_instances_from_file(
        train_tgt, max_word_seq_len, keep_case)

    if len(train_src_word_insts) != len(train_tgt_word_insts):
        print('[Warning] The training instance count is not equal.')
        min_inst_count = min(len(train_src_word_insts), len(train_tgt_word_insts))
        train_src_word_insts = train_src_word_insts[:min_inst_count]
        train_tgt_word_insts = train_tgt_word_insts[:min_inst_count]

    #- Remove empty instances
    train_src_word_insts, train_tgt_word_insts = list(zip(*[
        (s, t) for s, t in zip(train_src_word_insts, train_tgt_word_insts) if s and t]))

    # Validation set
    # valid_src_word_insts = read_instances_from_file(
    #     valid_src, max_word_seq_len, keep_case)
    # valid_tgt_word_insts = read_instances_from_file(
    #     valid_tgt, max_word_seq_len, keep_case)

    # if len(valid_src_word_insts) != len(valid_tgt_word_insts):
    #     print('[Warning] The validation instance count is not equal.')
    #     min_inst_count = min(len(valid_src_word_insts), len(valid_tgt_word_insts))
    #     valid_src_word_insts = valid_src_word_insts[:min_inst_count]
    #     valid_tgt_word_insts = valid_tgt_word_insts[:min_inst_count]

    #- Remove empty instances
    # valid_src_word_insts, valid_tgt_word_insts = list(zip(*[
    #     (s, t) for s, t in zip(valid_src_word_insts, valid_tgt_word_insts) if s and t]))

    #Test set
    test_src_word_insts = read_instances_from_file(
        test_src, max_word_seq_len, keep_case)
    test_tgt_word_insts = read_instances_from_file(
        test_tgt, max_word_seq_len, keep_case)

    if len(test_src_word_insts) != len(test_tgt_word_insts):
        print('[Warning] The test instance count is not equal.')
        min_inst_count = min(len(test_src_word_insts), len(test_tgt_word_insts))
        test_src_word_insts = test_src_word_insts[:min_inst_count]
        test_tgt_word_insts = test_tgt_word_insts[:min_inst_count]

    #- Remove empty instances
    test_src_word_insts, test_tgt_word_insts = list(zip(*[
        (s, t) for s, t in zip(test_src_word_insts, test_tgt_word_insts) if s and t]))

    # Build vocabulary 
    if vocab:
        predefined_data = torch.load(vocab)
        assert 'dict' in predefined_data

        print('[Info] Pre-defined vocabulary found.')
        src_word2idx = predefined_data['dict']['src']
        tgt_word2idx = predefined_data['dict']['tgt']
    else:
        if share_vocab:
            print('[Info] Build shared vocabulary for source and target.')
            word2idx = build_vocab_idx(
                train_src_word_insts + train_tgt_word_insts, min_word_count)
            src_word2idx = tgt_word2idx = word2idx
        else:
            print('[Info] Build vocabulary for source.')
            src_word2idx = build_vocab_idx(dataset_src_word_insts, min_word_count)
            print('[Info] Build vocabulary for target.')
            tgt_word2idx = build_vocab_idx(dataset_tgt_word_insts, min_word_count) 

    # word to index
    print('[Info] Convert source word instances into sequences of word index.')
    train_src_insts = convert_instance_to_idx_seq(train_src_word_insts, src_word2idx)
    # valid_src_insts = convert_instance_to_idx_seq(valid_src_word_insts, src_word2idx)
    test_src_insts = convert_instance_to_idx_seq(test_src_word_insts, src_word2idx)

    print('[Info] Convert target word instances into sequences of word index.')
    train_tgt_insts = convert_instance_to_idx_seq(train_tgt_word_insts, tgt_word2idx)
    # valid_tgt_insts = convert_instance_to_idx_seq(valid_tgt_word_insts, tgt_word2idx)
    test_tgt_insts = convert_instance_to_idx_seq(test_tgt_word_insts, tgt_word2idx)


    data = {
        'dict': {
            'src': src_word2idx,
            'tgt': tgt_word2idx},
        'train': {
            'src': train_src_insts,
            'tgt': train_tgt_insts},
        # 'valid': {
        #     'src': valid_src_insts,
        #     'tgt': valid_tgt_insts},
        'test': {
            'src': test_src_insts,
            'tgt': test_tgt_insts}
        }

    torch.save(data, './xrdata/mondial.pkl')
    print('[Info] Finish.')

if __name__ == '__main__':
    main()
