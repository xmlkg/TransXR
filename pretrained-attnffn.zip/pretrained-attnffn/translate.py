''' Translate input text with trained model. '''
import torch
import argparse
import numpy
from torch.autograd import Variable
import Constants
from beamsearch import Translator
from torch.utils.data import DataLoader
from model import make_model
from dataset import paired_collate_fn, collate_fn, TranslationDataset

def prepare_dataloaders(data):
	#=======Preparing Dataloader========#
	test_loader = torch.utils.data.DataLoader(
		TranslationDataset(
			src_word2idx=data['dict']['src'],
			tgt_word2idx=data['dict']['tgt'],
			src_insts=data['test']['src'],
			tgt_insts=data['test']['tgt']),
		num_workers = 2,
		batch_size = 1,
		collate_fn = paired_collate_fn,
		shuffle = False)
	return test_loader

def main():
#	  '''Main Function'''
	output_path = './predauctionattn_l1.txt'
	beam_size = 1
	max_seq_len = 1030
	is_cnn = False
	n_block = 6
	device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
	data = torch.load('./xrdata/aucdata.pkl')
	test_data = prepare_dataloaders(data)
	src_vocab_size = test_data.dataset.src_vocab_size
	tgt_vocab_size = test_data.dataset.tgt_vocab_size
	tgt_idx2word = {idx:word for word, idx in data['dict']['tgt'].items()}
	tgt_sep_idx = data['dict']['tgt'][Constants.UNK_WORD]
	tgt_pad_idx = data['dict']['tgt'][Constants.PAD_WORD]
	tgt_bos_idx = data['dict']['tgt'][Constants.BOS_WORD]
	tgt_eos_idx = data['dict']['tgt'][Constants.EOS_WORD]
	model = make_model(device, src_vocab_size, tgt_vocab_size, is_cnn, N=n_block)
	model.eval()
	translator = Translator(device, model, beam_size, tgt_vocab_size, max_seq_len, tgt_sep_idx, tgt_pad_idx, tgt_bos_idx, tgt_eos_idx).to(device)
	with open(output_path, 'a', encoding="utf-8") as f:
		for src, tgt in test_data:
			src = Variable(src, requires_grad=False).to(device)
			septoken = Variable(torch.full([src.size(0),1],Constants.UNK).long(),requires_grad=False).to(device)
			src = torch.cat((src,septoken),1)
			srclength = src.size(1)
			pred_seq = translator.beam_search(src)[:,srclength:]
			for i in range(pred_seq.size(0)):
				pred_line = ' '.join(str(tgt_idx2word[int(idx)]) for idx in pred_seq[i].tolist())
				pred_line = pred_line.replace(Constants.BOS_WORD, '').replace(Constants.EOS_WORD, '').replace(Constants.PAD_WORD, '')
				f.write(pred_line.strip() + '\n')
	print('[Info] Finished.')

if __name__ == "__main__":
	main()
