import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F 
import math,copy,time
import Constants
from torch.autograd import Variable


def clones(module,N):
	"Produce N identical layers."
	return nn.ModuleList([copy.deepcopy(module) for _ in range(N)])

def make_selfattn_mask(size, k):
	# size = data.size(-1)
	attn_mask = np.zeros([1, size, size]).astype('uint8')
	for i in range(size):
		for j in range(k):
			if (i-j>=0):
				attn_mask[0,i,i-j]=1
				# attn_mask[0,i,i+j]=1
	return attn_mask

# def make_selfattn_mask(data, issrc):
# 	batch_size = data.size(0)
# 	sen_length = data.size(-1)
# 	if issrc:
# 		indicator = Constants.SRCSEP
# 	else:
# 		indicator = Constants.TGTSEP
# 	attn_mask = np.zeros([batch_size, sen_length, sen_length]).astype('uint8')
# 	for i in range(batch_size):
# 		index = []
# 		for j in range(sen_length-1):
# 			if data[i,j] == indicator and data[i,j+1] == indicator:
# 				is_null.append(int(j)) 
# 		if len(index) <= 1:
# 			attn_mask[i] += 1
# 		else:
# 			attn_mask[i,0:index[0]+2,0:index[0]+2] += 1
# 			for m in range(len(index)):
# 				if 0<m<len(index):
# 					attn_mask[i,index[m-1]+2:index[m]+2,index[m-1]+2:index[m]+2] += 1
# 	return attn_mask

def make_enc_doc_mask(src, tgt):
	src_size = src.size(-1)
	tgt_size = tgt.size(-1)
	enc_doc_mask = np.zeros([1, tgt_size, src_size]).astype('uint8')
	for i in range(tgt_size):
		# for j in range(3*int(i/4), min(5*int(i/4)+3,src_size)):
		# 	enc_doc_mask[0,i,j] = 1
		for j in range(src_size):
			if (i-1>=0 and j==i-1) or j== i or j==i+1:
				enc_doc_mask[0,i,j] = 1
	return enc_doc_mask

# def make_enc_doc_mask(src, tgt):
# 	src_size = src.size(-1)
# 	tgt_size = tgt.size(-1)
# 	batch_size = src.size(0)
# 	enc_doc_mask = np.zeros([batch_size, tgt_size, src_size]).astype('uint8')
# 	for i in range(batch_size):
# 		# for j in range(3*int(i/4), min(5*int(i/4)+3,src_size)):
# 		# 	enc_doc_mask[0,i,j] = 1
# 		indi_src = []
# 		indi_tgt = []
# 		for j in range(src_size-1):
# 			if src[i,j] == Constants.SRCSEP and src[i,j+1] == Constants.SRCSEP:
# 				indi_src.append(int(j))
# 		for k in range(tgt_size-1):
# 			if tgt[i,k] == Constants.TGTSEP and tgt[i,k+1] == Constants.TGTSEP:
# 				indi_tgt.append(int(k))
# 		if len(indi_src) == len(indi_tgt):
# 			if len(indi_src)<=1:
# 				for n in range(tgt_size):
# 					enc_doc_mask[i,:,:] = 1
# 			else:
# 				for m in range(len(indi_src)):
# 					if m==0:
# 						for x in range(indi_tgt[m]+2):
# 							for y in range(indi_src[m]+2):
# 								if x == y:
# 									enc_doc_mask[i,x,y] = 1
# 					else:
# 						for w in range(indi_tgt[m-1]+2,indi_tgt[m]+2):
# 							for u in range(indi_src[m-1]+2,indi_src[m]+2):
# 								if w==u:
# 									enc_doc_mask[i,w,u] = 1
		
# 	return enc_doc_mask

def subsequent_mask(size):
	"Mask out subsequent positions."
	attn_shape = (1,size,size)
	subsequent_mask = np.triu(np.ones(attn_shape),k=1).astype('uint8')
	return torch.from_numpy(subsequent_mask) == 0

class SublayerConnection(nn.Module):
	"""A residual connection followed by a layer norm. Note for code simplicity the norm is first as oppose  to last.
	"""
	def __init__(self,size,dropout):
		super(SublayerConnection,self).__init__()
		self.norm = LayerNorm(size)
		self.dropout = nn.Dropout(dropout)

	def forward(self,x,sublayer):
		"Apply residual connection to any sublayer with the same size."
		return x + self.dropout(sublayer(self.norm(x)))
		

class LayerNorm(nn.Module):
	"Construct a layernorm module(See citation for details)."
	def __init__(self,features,eps=1e-6):
		super(LayerNorm,self).__init__()
		self.a_2 = nn.Parameter(torch.ones(features))
		self.b_2 = nn.Parameter(torch.zeros(features))
		self.eps = eps

	def forward(self,x):
		mean = x.mean(-1,keepdim=True)
		std = x.std(-1,keepdim=True)
		return self.a_2*(x-mean) / (std + self.eps) + self.b_2