from learn_bpe import learn_bpe
from apply_bpe import BPE
import codecs
import os
import sys
def encode_file(bpe, in_file, out_file):
	sys.stderr.write(f"Read raw content from {in_file} and \n"\
			f"Write encoded content to {out_file}\n")
	
	with codecs.open(in_file, encoding='utf-8') as in_f:
		with codecs.open(out_file, 'w', encoding='utf-8') as out_f:
			for line in in_f:
				out_f.write(bpe.process_line(line))


def encode_files(srcbpe, src_in_file, trg_in_file):
	src_out_file = 'bpeauction.xml'
	trg_out_file = 'bpeauction.n3'

	if os.path.isfile(src_out_file) and os.path.isfile(trg_out_file):
		sys.stderr.write(f"Encoded files found, skip the encoding process ...\n")

	# encode_file(srcbpe, src_in_file, src_out_file)
	encode_file(tgtbpe, trg_in_file, trg_out_file)
	return src_out_file, trg_out_file

# learn_bpe(['auction.xml'], 'srcvocab.txt', 32000, 30, True)
learn_bpe(['auction.n3'], 'tgtvocab.txt', 32000, 30, True)

# with codecs.open('srcvocab.txt', encoding='utf-8') as srccodes: 
# 	srcbpe = BPE(srccodes, separator=' ')
with codecs.open('tgtvocab.txt', encoding='utf-8') as tgtcodes: 
	tgtbpe = BPE(tgtcodes, separator=' ')
encode_files(tgtbpe,'auction.xml','auction.n3')
