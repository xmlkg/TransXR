from xml.dom.minidom import parse

def readXML():
	filename = './custacc.n3'
	domTree = parse("./batch-1.xml")
	#文档根元素Customers
	rootNode = domTree.documentElement
	#Customers子元素Customer
	customers = rootNode.getElementsByTagName("Customer")
	for customer in customers:
		if customer.hasAttribute("id"):
			customer_item = str("custacc:")+str(customer.nodeName)+str(customer.getAttribute("id"))
			mediannull = ' #'+' # '
			# Mnemonic元素
			mnemonic = customer.getElementsByTagName("Mnemonic")[0]
			# ShortNames元素
			Shortnames = customer.getElementsByTagName("ShortNames")[0]
			# ShortName元素
			shortname = Shortnames.getElementsByTagName("ShortName")[0]
			name = customer.getElementsByTagName("Name")[0]
			# #Title元素
			# title = name.getElementsByTagName("Title")[0]
			dateofbirth = customer.getElementsByTagName("DateOfBirth")[0]
			#Gender元素
			gender = customer.getElementsByTagName("Gender")[0]
			#Nationslity元素
			# nationality_var = ''
			# nationality = customer.getElementsByTagName("Nationslity")
			# if len(nationality)>0:
				# nationality_var = str("custacc:")+str(nationality.nodeName)+' '+str(nationality.childNodes[0].data.replace(' ','_'))+mediannull
			#Addresses元素
			Address = customer.getElementsByTagName("Addresses")[0]
			#Address元素
			address = Address.getElementsByTagName("Address")[0]
			gstreet = address.getElementsByTagName("gStreet")[0]
			street = gstreet.getElementsByTagName("Street")[0]
			city = address.getElementsByTagName("City")[0]
			state = address.getElementsByTagName("State")[0]
			country  = address.getElementsByTagName("Country")[0]
			Phones = address.getElementsByTagName("Phones")[0]
			phone = Phones.getElementsByTagName("Phone")
			phone_var = ""
			if len(phone)>0:
				countrycode = phone[0].getElementsByTagName("CountryCode")[0]
				areacode = phone[0].getElementsByTagName("AreaCode")[0]
				number = phone[0].getElementsByTagName("Number")[0]
				phone_var = str("custacc:")+str(address.nodeName)+str(customer.getAttribute("id"))+' '+str("custacc:hasPhone")+' '+str("custacc:")+str(phone[0].nodeName)+str(customer.getAttribute("id"))+mediannull+\
						str("custacc:")+str(phone[0].nodeName)+str(customer.getAttribute("id"))+' '+str("rdf:type")+' '+str("custacc:")+str(phone[0].nodeName)+mediannull+\
						str("custacc:")+str(phone[0].nodeName)+str(customer.getAttribute("id"))+' '+str("custacc:primary")+' '+str(phone[0].getAttribute("primary"))+mediannull+\
						str("custacc:")+str(phone[0].nodeName)+str(customer.getAttribute("id"))+' '+str("custacc:type")+' '+str(phone[0].getAttribute("type"))+mediannull+\
						str("custacc:")+str(phone[0].nodeName)+str(customer.getAttribute("id"))+' '+str("custacc:")+str(countrycode.nodeName)+' '+str(countrycode.childNodes[0].data.replace(' ','_'))+mediannull+\
						str("custacc:")+str(phone[0].nodeName)+str(customer.getAttribute("id"))+' '+str("custacc:")+str(areacode.nodeName)+' '+str(areacode.childNodes[0].data.replace(' ','_'))+mediannull+\
						str("custacc:")+str(phone[0].nodeName)+str(customer.getAttribute("id"))+' '+str("custacc:")+str(number.nodeName)+' '+str(number.childNodes[0].data.replace(' ','_'))+mediannull

			#Accounts元素
			Account = customer.getElementsByTagName("Accounts")[0]
			#Account元素
			account = Account.getElementsByTagName("Account")[0]
			category = account.getElementsByTagName("Category")[0]
			accounttitle = account.getElementsByTagName("AccountTitle")[0]
			# shorttitle = account.getElementsByTagName("ShortTitle")[0]
			mnemonic = account.getElementsByTagName("Mnemonic")[0]
			currency = account.getElementsByTagName("Currency")[0]
			with open(filename,'a') as file_object:
				file_object.write(
					customer_item+' '+str("custacc:id")+' '+str(customer.getAttribute("id"))+mediannull+\
					customer_item+' '+str('rdf:type')+' '+str('custacc:')+str(customer.nodeName)+mediannull+\
					customer_item+' '+str("custacc:")+str(mnemonic.nodeName)+' '+str(mnemonic.childNodes[0].data.replace(' ','_'))+mediannull+\
					# str(shortname.nodeName)+' '+str(shortname.childNodes[0].data.replace(' ','_'))+mediannull+\
					# str(title.nodeName)+' '+str(title.childNodes[0].data.replace(' ','_'))+mediannull+\
					customer_item+' '+str("custacc:")+str(dateofbirth.nodeName)+' '+str(dateofbirth.childNodes[0].data.replace(' ','_'))+mediannull+\
					customer_item+' '+str("custacc:")+str(gender.nodeName)+' '+str(gender.childNodes[0].data.replace(' ','_'))+mediannull+\
					# customer_item+' '+nationality_var+\
					customer_item+' '+str("custacc:hasAddress")+' '+str("custacc:")+str(address.nodeName)+str(customer.getAttribute("id"))+mediannull+\
					str("custacc:")+str(address.nodeName)+str(customer.getAttribute("id"))+' '+str("rdf:type")+' '+str("custacc:")+str(address.nodeName)+mediannull+\
					str("custacc:")+str(address.nodeName)+str(customer.getAttribute("id"))+' '+str("custacc:primary")+' '+str(address.getAttribute("primary"))+mediannull+\
					str("custacc:")+str(address.nodeName)+str(customer.getAttribute("id"))+' '+str("custacc:type")+' '+str(address.getAttribute("type"))+mediannull+\
					str("custacc:")+str(address.nodeName)+str(customer.getAttribute("id"))+' '+str("custacc:")+str(street.nodeName)+' '+str(street.childNodes[0].data.replace(' ','_'))+mediannull+\
					str("custacc:")+str(address.nodeName)+str(customer.getAttribute("id"))+' '+str("custacc:")+str(city.nodeName)+' '+str(city.childNodes[0].data.replace(' ','_'))+mediannull+\
					str("custacc:")+str(address.nodeName)+str(customer.getAttribute("id"))+' '+str("custacc:")+str(state.nodeName)+' '+str(state.childNodes[0].data.replace(' ','_'))+mediannull+\
					str("custacc:")+str(address.nodeName)+str(customer.getAttribute("id"))+' '+str("custacc:")+str(country.nodeName)+' '+str(country.childNodes[0].data.replace(' ','_'))+mediannull+\
					phone_var+ customer_item+' '+str("hasAccount")+' '+str("custacc:")+str(account.nodeName)+str(account.getAttribute("id"))+mediannull+\
					str("custacc:")+str(account.nodeName)+str(account.getAttribute("id"))+' '+str("custacc:id")+' '+str(account.getAttribute("id"))+mediannull+\
					str("custacc:")+str(account.nodeName)+str(account.getAttribute("id"))+' '+str("rdf:type")+' '+str("custacc:")+str(account.nodeName)+mediannull+\
					str("custacc:")+str(account.nodeName)+str(account.getAttribute("id"))+' '+str("custacc:")+str(category.nodeName)+' '+str(category.childNodes[0].data.replace(' ','_'))+mediannull+\
					str("custacc:")+str(account.nodeName)+str(account.getAttribute("id"))+' '+str("custacc:")+str(accounttitle.nodeName)+' '+str(accounttitle.childNodes[0].data.replace(' ','_'))+mediannull+\
					str("custacc:")+str(account.nodeName)+str(account.getAttribute("id"))+' '+str("custacc:")+str(mnemonic.nodeName)+' '+str(mnemonic.childNodes[0].data.replace(' ','_'))+mediannull+\
					str("custacc:")+str(account.nodeName)+str(account.getAttribute("id"))+' '+str("custacc:")+str(currency.nodeName)+' '+str(currency.childNodes[0].data.replace(' ','_'))+mediannull+str('\n')
					)


if __name__ == '__main__':
	readXML()
