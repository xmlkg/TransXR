from xml.dom.minidom import parse

def readXML():
	filename = './custacc.xml'
	domTree = parse("./batch-1.xml")
	#文档根元素Customers
	rootNode = domTree.documentElement
	#Customers子元素Customer
	customers = rootNode.getElementsByTagName("Customer")
	for customer in customers:
		if customer.hasAttribute("id"):
			customer_item = str(customer.nodeName)
			mediannull = ' null'+' null '
			# Mnemonic元素
			mnemonic = customer.getElementsByTagName("Mnemonic")[0]
			# ShortNames元素
			Shortnames = customer.getElementsByTagName("ShortNames")[0]
			# ShortName元素
			shortname = Shortnames.getElementsByTagName("ShortName")[0]
			name = customer.getElementsByTagName("Name")[0]
			# #Title元素
			# title = name.getElementsByTagName("Title")[0]
			dateofbirth = customer.getElementsByTagName("DateOfBirth")[0]
			#Gender元素
			gender = customer.getElementsByTagName("Gender")[0]
			#Nationslity元素
			nationality_var = ''
			nationality = customer.getElementsByTagName("Nationslity")
			if len(nationality)>0:
				nationality_var = str(nationality.nodeName)+' '+str(nationality.childNodes[0].data.replace(' ','_'))+mediannull
			#Addresses元素
			Address = customer.getElementsByTagName("Addresses")[0]
			#Address元素
			address = Address.getElementsByTagName("Address")[0]
			gstreet = address.getElementsByTagName("gStreet")[0]
			street = gstreet.getElementsByTagName("Street")[0]
			city = address.getElementsByTagName("City")[0]
			state = address.getElementsByTagName("State")[0]
			country  = address.getElementsByTagName("Country")[0]
			Phones = address.getElementsByTagName("Phones")[0]
			phone = Phones.getElementsByTagName("Phone")
			phone_var = ""
			if len(phone)>0:
				countrycode = phone[0].getElementsByTagName("CountryCode")[0]
				areacode = phone[0].getElementsByTagName("AreaCode")[0]
				number = phone[0].getElementsByTagName("Number")[0]
				phone_var = str(phone[0].nodeName)+' '+str("primary")+' '+str(phone[0].getAttribute("primary"))+mediannull+\
						str("type")+' '+str(phone[0].getAttribute("type"))+mediannull+\
						str(countrycode.nodeName)+' '+str(countrycode.childNodes[0].data.replace(' ','_'))+mediannull+\
						str(areacode.nodeName)+' '+str(areacode.childNodes[0].data.replace(' ','_'))+mediannull+\
						str(number.nodeName)+' '+str(number.childNodes[0].data.replace(' ','_'))+mediannull

			#Accounts元素
			Account = customer.getElementsByTagName("Accounts")[0]
			#Account元素
			account = Account.getElementsByTagName("Account")[0]
			category = account.getElementsByTagName("Category")[0]
			accounttitle = account.getElementsByTagName("AccountTitle")[0]
			# shorttitle = account.getElementsByTagName("ShortTitle")[0]
			mnemonic = account.getElementsByTagName("Mnemonic")[0]
			currency = account.getElementsByTagName("Currency")[0]
			with open(filename,'a') as file_object:
				file_object.write(customer_item+' '+\
					str("id")+' '+str(customer.getAttribute("id"))+mediannull+\
					str(mnemonic.nodeName)+' '+str(mnemonic.childNodes[0].data.replace(' ','_'))+mediannull+\
					# str(shortname.nodeName)+' '+str(shortname.childNodes[0].data.replace(' ','_'))+mediannull+\
					# str(title.nodeName)+' '+str(title.childNodes[0].data.replace(' ','_'))+mediannull+\
					str(dateofbirth.nodeName)+' '+str(dateofbirth.childNodes[0].data.replace(' ','_'))+mediannull+\
					str(gender.nodeName)+' '+str(gender.childNodes[0].data.replace(' ','_'))+mediannull+\
					nationality_var+\
					str(address.nodeName)+' '+\
					str("primary")+' '+str(address.getAttribute("primary"))+mediannull+\
					str("type")+' '+str(address.getAttribute("type"))+mediannull+\
					str(street.nodeName)+' '+str(street.childNodes[0].data.replace(' ','_'))+mediannull+\
					str(city.nodeName)+' '+str(city.childNodes[0].data.replace(' ','_'))+mediannull+\
					str(state.nodeName)+' '+str(state.childNodes[0].data.replace(' ','_'))+mediannull+\
					str(country.nodeName)+' '+str(country.childNodes[0].data.replace(' ','_'))+mediannull+\
					phone_var+ str(account.nodeName)+' '+str("id")+' '+str(account.getAttribute("id"))+mediannull+\
					str(category.nodeName)+' '+str(category.childNodes[0].data.replace(' ','_'))+mediannull+\
					str(accounttitle.nodeName)+' '+str(accounttitle.childNodes[0].data.replace(' ','_'))+mediannull+\
					str(mnemonic.nodeName)+' '+str(mnemonic.childNodes[0].data.replace(' ','_'))+mediannull+\
					str(currency.nodeName)+' '+str(currency.childNodes[0].data.replace(' ','_'))+mediannull+str('\n')
					)


if __name__ == '__main__':
	readXML()
