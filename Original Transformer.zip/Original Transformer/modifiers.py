import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F 
import math,copy,time
import Constants
from torch.autograd import Variable


def clones(module,N):
	"Produce N identical layers."
	return nn.ModuleList([copy.deepcopy(module) for _ in range(N)])

def make_selfattn_mask(data, k):
	size = data.size(-1)
	attn_mask = np.zeros([1, size, size]).astype('uint8')
	for i in range(size):
		for j in range(k):
			if (i-j>=0):
				attn_mask[0,i,i-j]=1
				# attn_mask[0,i,i+j]=1
	return attn_mask

def subsequent_mask(size):
	"Mask out subsequent positions."
	attn_shape = (1,size,size)
	subsequent_mask = np.triu(np.ones(attn_shape),k=1).astype('uint8')
	return torch.from_numpy(subsequent_mask) == 0

class SublayerConnection(nn.Module):
	"""A residual connection followed by a layer norm. Note for code simplicity the norm is first as oppose  to last.
	"""
	def __init__(self,size,dropout):
		super(SublayerConnection,self).__init__()
		self.norm = LayerNorm(size)
		self.dropout = nn.Dropout(dropout)

	def forward(self,x,sublayer):
		"Apply residual connection to any sublayer with the same size."
		return x + self.dropout(sublayer(self.norm(x)))
		

class LayerNorm(nn.Module):
	"Construct a layernorm module(See citation for details)."
	def __init__(self,features,eps=1e-6):
		super(LayerNorm,self).__init__()
		self.a_2 = nn.Parameter(torch.ones(features))
		self.b_2 = nn.Parameter(torch.zeros(features))
		self.eps = eps

	def forward(self,x):
		mean = x.mean(-1,keepdim=True)
		std = x.std(-1,keepdim=True)
		return self.a_2*(x-mean) / (std + self.eps) + self.b_2