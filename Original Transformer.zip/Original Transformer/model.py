import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F 
import math,copy,time
import sublayers_cnn, sublayers_ffn
from torch.autograd import Variable
from layers import EncoderLayer, DecoderLayer
# from sublayers import MultiHeadAttention, PositionwiseFeedForward
from embedding import Embedding 
from positionalencoding import PositionalEncoding
from modifiers import clones, LayerNorm  

class Encoder(nn.Module):
	"Core encoder is a stack of N layers"
	def __init__(self, layer, N):
		super(Encoder,self).__init__()
		self.layers = clones(layer,N)
		self.norm = LayerNorm(layer.size)

	def forward(self,x,mask):
		"Pass the input (and mask) through each layer in turn."
		for layer in self.layers:
			x = layer(x,mask)
		return self.norm(x)

class Decoder(nn.Module):
	"Generic N layer decoder with masking."
	def __init__(self, layer, N):
		super(Decoder,self).__init__()
		self.layers = clones(layer, N)
		self.norm = LayerNorm(layer.size)

	def forward(self,x,memory,src_mask,tgt_mask):
		for layer in self.layers:
			x = layer(x,memory,src_mask,tgt_mask)
		return self.norm(x)

class Generator(nn.Module):
	"Define standard linear + softmax generation step."
	def __init__(self, d_model, vocab):
		super(Generator,self).__init__()
		self.proj = nn.Linear(d_model, vocab)
		self.d_model = d_model
	def forward(self,x):
		return F.log_softmax(self.proj(x), dim=-1)
# (self.d_model **(-0.5))* 

class EncoderDecoder(nn.Module):
	"""
	A standard Encoder-Decoder architecture. Base for this and many other models.
	"""
	def __init__(self, encoder, decoder, src_embed, tgt_embed,generator):
		super(EncoderDecoder,self).__init__()
		self.encoder = encoder
		self.decoder = decoder
		self.src_embed = src_embed
		self.tgt_embed = tgt_embed
		self.generator = generator
		# if True:
		# 	self.src_embed[0].lut.weight = self.tgt_embed[0].lut.weight
		# 	self.generator.proj.weight = self.tgt_embed[0].lut.weight
	def forward(self, src, tgt, src_mask, enc_dec_mask, tgt_mask):
		"Take in and process masked src and target sequence."
		return self.decode(self.encode(src, src_mask), enc_dec_mask, tgt, tgt_mask)

	def encode(self, src, src_mask):
		return self.encoder(self.src_embed(src), src_mask)

	def decode(self, memory, enc_dec_mask, tgt, tgt_mask):
		return self.decoder(self.tgt_embed(tgt), memory, enc_dec_mask, tgt_mask)


def make_model(device, src_vocab, tgt_vocab, is_cnn, N=6, d_model=512, d_ff=2048, h=8, dropout=0.1):
	"Helper: Construct a model from hyperparameters."
	c = copy.deepcopy
	if is_cnn:
		attn = sublayers_cnn.MultiHeadAttention(h,d_model)
		ff = sublayers_cnn.PositionwiseFeedForward(device, d_model,d_ff,dropout)
	else:
		attn = sublayers_ffn.MultiHeadAttention(h,d_model)
		ff = sublayers_ffn.PositionwiseFeedForward(device, d_model,d_ff,dropout)
	position = PositionalEncoding(d_model,dropout)
	model = EncoderDecoder(\
		Encoder(EncoderLayer(d_model,c(attn),c(ff),dropout),N),\
		Decoder(DecoderLayer(d_model,c(attn),c(attn),c(ff),dropout),N),\
		nn.Sequential(Embedding(d_model,src_vocab),c(position)),\
		nn.Sequential(Embedding(d_model,tgt_vocab),c(position)),\
		Generator(d_model,tgt_vocab)).to(device)
	# This was important from their code.
	# Initialize parameters with Glorot / fan_avg.
	model.load_state_dict(torch.load('./xrdata/bpemodelcustaccffn.pkl'))
	# for p in model.parameters():
		# if p.dim() > 1:
			# nn.init.xavier_uniform_(p)
	return model