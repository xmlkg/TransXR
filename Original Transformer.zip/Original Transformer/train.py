import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F 
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pylab as pyl
import math, copy, time
import Constants
from torch.autograd import Variable
from torch.utils.data import DataLoader
from optim import NoamOpt
from model import make_model
from modifiers import subsequent_mask
from dataset import paired_collate_fn, collate_fn, TranslationDataset


# Batches and Masking make_selfattn_mask, make_enc_doc_mask, 
class Batch:
	"Object for holding a batch of data with mask during training."
	def __init__(self, device,src, trg=None, pad=0, k=3):
		self.src = src
		if trg is not None:
			self.trg = trg[:, :-1]
			self.trg_y = trg[:, 1:]
			self.src_mask, self.enc_dec_mask, self.trg_mask = self.make_std_mask(device, self.src, self.trg, pad, k)
			self.ntokens = (self.trg_y != pad).data.sum()
				
	@staticmethod
	def make_std_mask(device, src, tgt, pad, k):
		"Creat a mask to hide padding and irrelevant words for src and future words for tgt."
		src_mask = (src != pad).unsqueeze(-2)
		tgt_mask = (tgt != pad).unsqueeze(-2)
		enc_dec_mask = src_mask 
		# & Variable((torch.from_numpy(make_enc_doc_mask(src,tgt)) == 1).type_as(src_mask.data))
		# src_mask = src_mask & Variable((torch.from_numpy(make_selfattn_mask(src,k)) == 1).type_as(src_mask.data)).to(device)
		tgt_mask = tgt_mask & Variable(subsequent_mask(tgt.size(-1)).type_as(tgt_mask.data)) 
		 # & \  Variable((torch.from_numpy(make_selfattn_mask(tgt,k)) == 1).type_as(tgt_mask.data)).to(device)
		return src_mask, enc_dec_mask, tgt_mask

#Regularization
class LabelSmoothing(nn.Module):
	"Implement label smoothing."
	def __init__(self, size, padding_idx, smoothing=0.0):
		super(LabelSmoothing, self).__init__()
		self.criterion = nn.KLDivLoss(reduction='sum')
		self.padding_idx = padding_idx
		self.confidence = 1.0 - smoothing
		self.smoothing = smoothing
		self.size = size
		self.true_dist = None

	def forward(self, x, target):
		assert x.size(1) == self.size
		true_dist = x.data.clone()
		true_dist.fill_(self.smoothing / (self.size - 2))
		true_dist.scatter_(1, target.data.unsqueeze(1), self.confidence)
		true_dist[:, self.padding_idx] = 0
		mask = torch.nonzero(target.data == self.padding_idx)
		if mask.dim() > 0:
			true_dist.index_fill_(0, mask.squeeze(), 0.0)
			self.true_dist = true_dist
		return self.criterion(x, Variable(true_dist, requires_grad=False))


# Loss Computation
class SimpleLossCompute:
	"A simple loss compute and train function."
	def __init__(self, generator, criterion, opt=None):
		self.generator = generator
		self.criterion = criterion
		self.opt = opt

	def __call__(self, i, x, y, norm):
		x = self.generator(x)
		loss = self.criterion(x.contiguous().view(-1,x.size(-1)), y.contiguous().view(-1))/norm.float()
		loss.backward()
		if self.opt is not None:
			if (i+1)%4==0:
				self.opt.step()
				self.opt.optimizer.zero_grad()
		return loss.cpu().float().item() * norm.float()


#Training Loop
def run_epoch(device, data_iter, model, loss_compute):
	"Standard Training and logging Function"
	start = time.time()
	total_correct_tokens = 0.
	total_tokens = 0.
	total_loss = 0.
	tokens = 0.
	i = 0
	for src, tgt in data_iter:
		src = Variable(src, requires_grad=False).to(device)
		tgt = Variable(tgt, requires_grad=False).to(device)
		batch = Batch(device, src, tgt, 0, 3)
		out = model.forward(batch.src, batch.trg, batch.src_mask, batch.enc_dec_mask, batch.trg_mask)
		loss = loss_compute(i, out, batch.trg_y, batch.ntokens)
		out = model.generator(out).cpu()
		total_loss += loss.item()
		pred = out.view(-1, out.size(2)).max(1)[1]
		gold = batch.trg_y.cpu().contiguous().view(-1)
		non_pad_mask = gold.ne(0)
		n_correct = pred.eq(gold).masked_select(non_pad_mask).sum().item()
		total_correct_tokens += n_correct
		total_tokens += batch.ntokens.cpu().item()
		# if i%50==1:
		# 	print(pred)
		# 	print(gold)
		# 	print(n_correct)
		# i += 1
		# tokens += batch.ntokens.cpu().numpy() 
		# if i%50 == 1:
		# 	elapsed = time.time() - start
		# 	print("Epoch Step: %d Loss: %f Tokens per Sec: %f" % (i, loss.detach().cpu().numpy()/batch.ntokens.cpu().numpy(), tokens/elapsed))
		# 	start = time.time()
		# 	tokens = 0
		i += 1
	return total_loss / total_tokens, total_correct_tokens / total_tokens

# Output loss and draw the loss picture
def output_result(is_auction_dataset, is_cnn, Epoch_Num, n_block, epoch_list, epoch_loss_list):
	if is_cnn:
		label_model = "CNN "
		if is_auction_dataset:
			file_name = './auction_attncnn_'+str(Epoch_Num)+'_'+str(n_block)+'.txt'
		else:
			file_name = './mondial_attncnn_'+str(Epoch_Num)+'_'+str(n_block)+'.txt'
	else:
		label_model = "FFN "
		if is_auction_dataset:
			file_name = './auction_attnffn_'+str(Epoch_Num)+'_'+str(n_block)+'.txt'
		else:
			file_name = './mondial_attnffn_'+str(Epoch_Num)+'_'+str(n_block)+'.txt'
	with open(file_name, 'a') as file_object:
		file_object.write(str("model=")+str(label_model)+' '+str("epochnum=")+str(Epoch_Num)+' '+str("blocknum=")+' '+str(n_block)+str("\n"))
		for epoch, epochloss in zip(epoch_list, epoch_loss_list):
			file_object.write(str("Epoch: ")+str(epoch)+str(" Epoch_Loss: ")+str(epochloss)+str("\n"))
	pyl.plot(epoch_list, epoch_loss_list, 'r-o', label="Train_Loss")
	pyl.legend(ncol=1)
	pyl.xlabel("Epoches")
	pyl.ylabel("Loss")
	pyl.xlim(0,Epoch_Num)
	pyl.ylim(0,int(max(epoch_loss_list))+1)
	plt.savefig("picture1.png")
	pyl.show()

def main():
	is_cnn = False
	is_auction_dataset = False
	Epoch_Num = 1
	n_block = 1
	epoch_list = []
	epoch_loss_list = []
	epoch_accuracy_list = []
	epoch_perplexity_list = []
	device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
	data = torch.load('./xrdata/bpecustacc_data.pkl')
	data = torch.load('./xrdata/bpeauction_data.pkl')
	training_data, valid_data, test_data = prepare_dataloaders(data)
	src_vocab_size = training_data.dataset.src_vocab_size
	tgt_vocab_size = training_data.dataset.tgt_vocab_size
	criterion = LabelSmoothing(size=tgt_vocab_size, padding_idx=0, smoothing=0.0)
	model = make_model(device, src_vocab_size, tgt_vocab_size, is_cnn, N=n_block)
	
	# model = model.to(device)
	model_opt = NoamOpt(512, 1, 400, torch.optim.Adam(model.parameters(), lr=0, betas=(0.9,0.98), eps=1e-9))
	for epoch in range(Epoch_Num):
		model.train()
		epoch_trainloss, epoch_trainaccuracy = run_epoch(device, training_data, model, SimpleLossCompute(model.generator, criterion, model_opt))
		print("Epoch: %d Epoch_TrainLoss: %f Epoch_TrainAccuracy: %f" % (epoch, epoch_trainloss, epoch_trainaccuracy))
		epoch_list.append(epoch)
		epoch_loss_list.append(epoch_trainloss)
		model.eval()
		
		epoch_validloss, epoch_validaccuracy = run_epoch(device, valid_data, model, SimpleLossCompute(model.generator, criterion, None))
		epoch_perplexity = math.exp(epoch_validloss)
		print("Epoch: %d Perplexity: %f Epoch_validAccuracy: %f" % (epoch, epoch_perplexity,epoch_validaccuracy))
		
		epoch_testloss, epoch_testaccuracy = run_epoch(device, test_data, model, SimpleLossCompute(model.generator, criterion, None))
		epoch_perplexity = math.exp(epoch_testloss)
		print("Epoch: %d Perplexity: %f Epoch_TestAccuracy: %f" % (epoch, epoch_perplexity,epoch_testaccuracy))
		epoch_perplexity_list.append(epoch_perplexity)
		epoch_accuracy_list.append(epoch_testaccuracy)
		torch.save(model.state_dict(), './xrdata/bpemodelauctioncnn.pkl')
	output_result(is_auction_dataset, is_cnn, Epoch_Num, n_block, epoch_list, epoch_loss_list)
	output_result(is_auction_dataset, is_cnn, Epoch_Num, n_block, epoch_list, epoch_perplexity_list)
	output_result(is_auction_dataset, is_cnn, Epoch_Num, n_block, epoch_list, epoch_accuracy_list)

def prepare_dataloaders(data):
	#=======Preparing Dataloader========#
	train_loader = torch.utils.data.DataLoader(
		TranslationDataset(
			src_word2idx=data['dict']['src'],
			tgt_word2idx=data['dict']['tgt'],
			src_insts=data['train']['src'],
			tgt_insts=data['train']['tgt']),
		num_workers = 8,
		batch_size = 16,
		collate_fn = paired_collate_fn,
		shuffle = True)
		
	valid_loader = torch.utils.data.DataLoader(
		TranslationDataset(
			src_word2idx=data['dict']['src'],
			tgt_word2idx=data['dict']['tgt'],
			src_insts=data['valid']['src'],
			tgt_insts=data['valid']['tgt']),
		num_workers = 8,
		batch_size = 16,
		collate_fn = paired_collate_fn,
		shuffle = False)

	test_loader = torch.utils.data.DataLoader(
		TranslationDataset(
			src_word2idx=data['dict']['src'],
			tgt_word2idx=data['dict']['tgt'],
			src_insts=data['test']['src'],
			tgt_insts=data['test']['tgt']),
		num_workers = 2,
		batch_size = 16,
		collate_fn = paired_collate_fn,
		shuffle = False)
	return train_loader, test_loader


if __name__ == '__main__':
    main()