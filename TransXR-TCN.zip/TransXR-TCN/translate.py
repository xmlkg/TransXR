''' Translate input text with trained model. '''

import torch
import argparse
import numpy
from torch.autograd import Variable

import Constants
from beamsearch import Translator
from torch.utils.data import DataLoader
from model import make_model
from dataset import paired_collate_fn, collate_fn, TranslationDataset
from modifiers import subsequent_mask


# def load_model(model_path, device, src_vocab_size, tgt_vocab_size, is_cnn, n_block):

	# checkpoint = torch.load(opt.model, map_location=device)
	# model_opt = checkpoint['settings']
	# model = make_model(src_vocab_size, tgt_vocab_size, is_cnn, N=n_block).to(device)

	# model = Transformer(
	#	  model_opt.src_vocab_size,
	#	  model_opt.trg_vocab_size,

	#	  model_opt.src_pad_idx,
	#	  model_opt.trg_pad_idx,

	#	  # trg_emb_prj_weight_sharing=model_opt.proj_share_weight,
	#	  # emb_src_trg_weight_sharing=model_opt.embs_share_weight,
	#	  d_k=model_opt.d_k,
	#	  d_v=model_opt.d_v,
	#	  d_model=model_opt.d_model,
	#	  d_word_vec=model_opt.d_word_vec,
	#	  d_inner=model_opt.d_inner_hid,
	#	  n_layers=model_opt.n_layers,
	#	  n_head=model_opt.n_head,
	#	  dropout=model_opt.dropout).to(device)

	# model.load_state_dict(torch.load(model_path))
	# print('[Info] Trained model state loaded.')
	# return model 
def prepare_dataloaders(data):
	#=======Preparing Dataloader========#
	test_loader = torch.utils.data.DataLoader(
		TranslationDataset(
			src_word2idx=data['dict']['src'],
			tgt_word2idx=data['dict']['tgt'],
			src_insts=data['test']['src'],
			tgt_insts=data['test']['tgt']),
		num_workers = 2,
		batch_size = 1,
		collate_fn = paired_collate_fn,
		shuffle = False)
	return test_loader


def main():
#	  '''Main Function'''
	model_path = './xrdata/modelauctionattncnn.pkl'
	output_path = './predcustaccattnffn30_6block.txt'
	beam_size = 5
	max_seq_len = 250
	is_cnn = True
	n_block = 6
	# parser = argparse.ArgumentParser(description='translate.py')

	# parser.add_argument('-model', required=True,
	#					  help='Path to model weight file')
	# parser.add_argument('-data_pkl', required=True,
	#					  help='Pickle file with both instances and vocabulary.')
	# parser.add_argument('-output', default='pred.txt',
	#					  help="""Path to output the predictions (each line will
	#					  be the decoded sequence""")
	# parser.add_argument('-beam_size', type=int, default=5)
	# parser.add_argument('-max_seq_len', type=int, default=100)
	# parser.add_argument('-no_cuda', action='store_true')

	# TODO: Translate bpe encoded files 
	#parser.add_argument('-src', required=True,
	#					 help='Source sequence to decode (one line per sequence)')
	#parser.add_argument('-vocab', required=True,
	#					 help='Source sequence to decode (one line per sequence)')
	# TODO: Batch translation
	#parser.add_argument('-batch_size', type=int, default=30,
	#					 help='Batch size')
	#parser.add_argument('-n_best', type=int, default=1,
	#					 help="""If verbose is set, will output the n_best
	#					 decoded sentences""")

	# opt = parser.parse_args()
	# opt.cuda = not opt.no_cuda
	device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
	data = torch.load('./xrdata/bpecustacc_data.pkl')
	test_data = prepare_dataloaders(data)
	src_vocab_size = test_data.dataset.src_vocab_size
	tgt_vocab_size = test_data.dataset.tgt_vocab_size
	tgt_idx2word = {idx:word for word, idx in data['dict']['tgt'].items()}
	# SRC, TRG = data['vocab']['src'], data['vocab']['trg']
	src_pad_idx = data['dict']['src'][Constants.PAD_WORD]
	src_unk_idx = data['dict']['src'][Constants.UNK_WORD]
	tgt_pad_idx = data['dict']['tgt'][Constants.PAD_WORD]
	tgt_bos_idx = data['dict']['tgt'][Constants.BOS_WORD]
	tgt_eos_idx = data['dict']['tgt'][Constants.EOS_WORD]

	model = make_model(device, src_vocab_size, tgt_vocab_size, is_cnn, N=n_block)
	# model.load_state_dict(torch.load(model_path))
	model.eval()
	# test_loader = Dataset(examples=data['test'], fields={'src': SRC, 'trg': TRG})
	# load_model(model_path, device, src_vocab_size, tgt_vocab_size, is_cnn, n_block),\
	
	translator = Translator(device, model, beam_size, max_seq_len, src_pad_idx, tgt_pad_idx, tgt_bos_idx, tgt_eos_idx).to(device)
	# unk_idx = SRC.vocab.stoi[SRC.unk_token]
	with open(output_path, 'a', encoding="utf-8") as f:
		for src, tgt in test_data:
		# # for example in tqdm(test_loader, mininterval=2, desc='	- (Test)', leave=False):
		# #		#print(' '.join(example.src))
		#	  src_seq = [SRC.vocab.stoi.get(word, unk_idx) for word in example.src]
			src = Variable(src, requires_grad=False).to(device)
			# src_mask = (src != src_pad_idx).unsqueeze(-2)
			pred_seq = translator.translate_sentence(src)
			# pred_seq = greedy_decode(model, src, src_mask, max_len=80, start_symbol=2)[0]
			pred_line = ' '.join(str(tgt_idx2word[idx]) for idx in pred_seq)
			pred_line = pred_line.replace(Constants.BOS_WORD, '').replace(Constants.EOS_WORD, '')
			#print(pred_line)
			f.write(pred_line.strip() + '\n')

	print('[Info] Finished.')



# def greedy_decode(model, src, src_mask, max_len, start_symbol):
#	memory = model.encode(src, src_mask)
#	ys = torch.ones(1,1).fill_(start_symbol).type_as(src.data)
#	for i in range(max_len-1):
#		out = model.decode(memory, src_mask, Variable(ys), Variable(subsequent_mask(ys.size(1)).type_as(src.data)))
#		prob = model.generator(out[:,-1])
#		_, next_word = torch.max(prob, dim=1)
#		next_word = next_word.item()
#		ys = torch.cat([ys, torch.ones(1,1).type_as(src.data).fill_(next_word)], dim=1)
#	return ys

# def main():
#	model = torch.load('./xrdata/modelcnn.pkl')
#	model.eval()
#	data = torch.load('./xrdata/data.pkl')
#	test_data = prepare_dataloaders(data)
#	tgt_idx2word = {idx:word for word, idx in data['dict']['tgt'].items()}
#	print(data['dict']['src'].items())
#	print(tgt_idx2word.items())
#	device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
#	with open('./pred.txt', 'a', encoding="utf-8") as f:
#		for src, tgt in test_data:
#			src = Variable(src, requires_grad=False).to(device)
#			src_mask = (src != 0).unsqueeze(-2)
#			pred_seq = greedy_decode(model, src, src_mask, max_len=100, start_symbol=2)
#			pred_line = ' '.join([str(tgt_idx2word[int(idx.item())]) for idx in torch.squeeze(pred_seq)])
#			pred_line = pred_line.replace(Constants.BOS_WORD, '').replace(Constants.EOS_WORD, '')
#			f.write(pred_line.strip() + '\n')
	
#	print('[Info] Finished.')

if __name__ == "__main__":
	main()
