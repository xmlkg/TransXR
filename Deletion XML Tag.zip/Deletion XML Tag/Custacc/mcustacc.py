import random
def readRDF():
	file = open('./custacc.xml','r')
	filename = './mcustacc.xml'
	text_lines = file.readlines()
	customer_list = []
	# address_list = []
	# account_list = []
	# phone_list = []
	for i in range(len(text_lines)):
		customer_list.append(i)
		# if ' Customer ' in text_lines[i]:
		# 	customer_list.append(i)
		# if ' Address ' in text_lines[i]:
		# 	address_list.append(i)
		# if ' Account ' in text_lines[i]:
		# 	account_list.append(i)
		# if ' Phone ' in text_lines[i]:
		# 	phone_list.append(i)
	customer_id = random.sample(customer_list, int(0.2*len(customer_list)))
	customer_mnemonic = random.sample(customer_list, int(0.2*len(customer_list)))
	# customer_shortname = random.sample(customer_list, int(0.2*len(customer_list)))
	# customer_name = random.sample(customer_list, int(0.2*len(customer_list)))
	# customer_title = random.sample(customer_list, int(0.2*len(customer_list)))
	# customer_firstname = random.sample(customer_list, int(0.2*len(customer_list)))
	# customer_middlename = random.sample(customer_list, int(0.2*len(customer_list)))
	# customer_lastname = random.sample(customer_list, int(0.2*len(customer_list)))
	customer_dateofbirth = random.sample(customer_list, int(0.2*len(customer_list)))
	customer_gender = random.sample(customer_list, int(0.2*len(customer_list)))
	customer_nationality = random.sample(customer_list, int(0.2*len(customer_list)))
	# customer_countryofresidence = random.sample(customer_list, int(0.2*len(customer_list)))
	# customer_language = random.sample(customer_list, int(0.2*len(customer_list)))
	# customer_email = random.sample(customer_list, int(0.2*len(customer_list)))
	# customer_customersince = random.sample(customer_list, int(0.2*len(customer_list)))
	# customer_premiumcustomer = random.sample(customer_list, int(0.2*len(customer_list)))
	# customer_customerstatus = random.sample(customer_list, int(0.2*len(customer_list)))
	# customer_lastcontactdate = random.sample(customer_list, int(0.2*len(customer_list)))
	# customer_reviewfrequency = random.sample(customer_list, int(0.2*len(customer_list)))
	# customer_currency = random.sample(customer_list, int(0.2*len(customer_list)))

	address_primary = random.sample(customer_list, int(0.2*len(customer_list)))
	address_street = random.sample(customer_list, int(0.2*len(customer_list)))
	address_type = random.sample(customer_list, int(0.2*len(customer_list)))
	address_city = random.sample(customer_list, int(0.2*len(customer_list)))
	# address_postalcode = random.sample(address_list, int(0.2*len(address_list)))
	address_state = random.sample(customer_list, int(0.2*len(customer_list)))
	address_country = random.sample(customer_list, int(0.2*len(customer_list)))
	# address_citycountry = random.sample(address_list, int(0.2*len(address_list)))

	phone_primary = random.sample(customer_list, int(0.2*len(customer_list)))
	phone_type = random.sample(customer_list, int(0.2*len(customer_list)))
	phone_countrycode = random.sample(customer_list, int(0.2*len(customer_list)))
	phone_areacode = random.sample(customer_list, int(0.2*len(customer_list)))
	phone_number = random.sample(customer_list, int(0.2*len(customer_list)))
	# phone_extension = random.sample(phone_list, int(0.2*len(phone_list)))

	account_id = random.sample(customer_list, int(0.2*len(customer_list)))
	account_category = random.sample(customer_list, int(0.2*len(customer_list)))
	account_accounttile = random.sample(customer_list, int(0.2*len(customer_list)))
	# account_shorttitle = random.sample(account_list, int(0.2*len(account_list)))
	account_mnemonic = random.sample(customer_list, int(0.2*len(customer_list)))
	account_currency = random.sample(customer_list, int(0.2*len(customer_list)))
	# account_currencymarket = random.sample(account_list, int(0.2*len(account_list)))
	# account_openingdate = random.sample(account_list, int(0.2*len(account_list)))
	# account_accountofficer = random.sample(account_list, int(0.2*len(account_list)))
	# account_lastupdate = random.sample(account_list, int(0.2*len(account_list)))
	# account_passbook = random.sample(account_list, int(0.2*len(account_list)))
	# account_chargeccy = random.sample(account_list, int(0.2*len(account_list)))
	# account_interestccy = random.sample(account_list, int(0.2*len(account_list)))
	# account_allownetting = random.sample(account_list, int(0.2*len(account_list)))

	for i in range(len(text_lines)):
		if i in customer_id:
			text_lines[i]=text_lines[i][0:20].replace(' id ',' ')
		if i in customer_mnemonic:
			text_lines[i]=text_lines[i][0:50].replace(' Mnemonic ',' ')
		# if i in customer_shortname:
		# 	text_lines[i]=text_lines[i].replace(' ShortName ',' ')
		# 	if i in customer_name:
		# 		text_lines[i]=text_lines[i].replace(' Name ',' ')
		# 	if i in customer_title:
		# 		text_lines[i]=text_lines[i].replace(' Title ',' ')
		# 	if i in customer_firstname:
		# 		text_lines[i]=text_lines[i].replace(' FirstName ',' ')
		# 	if i in customer_middlename:
		# 		text_lines[i]=text_lines[i].replace(' MiddleName ',' ')
		# 	if i in customer_lastname:
		# 		text_lines[i]=text_lines[i].replace(' LastName ',' ')
		if i in customer_dateofbirth:
			text_lines[i]=text_lines[i].replace(' DateOfBirth ',' ')
		if i in customer_gender:
			text_lines[i]=text_lines[i].replace(' Gender ',' ')
		if i in customer_nationality:
			text_lines[i]=text_lines[i].replace(' Nationslity ',' ')
		# 	if i in customer_countryofresidence:
		# 		text_lines[i]=text_lines[i].replace(' CountryOfResidence ',' ')
		# 	if i in customer_language:
		# 		text_lines[i]=text_lines[i].replace(' Language ',' ')
		# 	if i in customer_email:
		# 		text_lines[i]=text_lines[i].replace(' Email ',' ')
		# 	if i in customer_customersince:
		# 		text_lines[i]=text_lines[i].replace(' CustomerSince ',' ')
		# 	if i in customer_premiumcustomer:
		# 		text_lines[i]=text_lines[i].replace(' PremiumCustomer ',' ')
		# 	if i in customer_customerstatus:
		# 		text_lines[i]=text_lines[i].replace(' CustomerStatus ',' ')
		# 	if i in customer_lastcontactdate:
		# 		text_lines[i]=text_lines[i].replace(' LastContactDate ',' ')
		# 	if i in customer_reviewfrequency:
		# 		text_lines[i]=text_lines[i].replace(' ReviewFrequency ',' ')
		# 	if i in customer_currency:
		# 		text_lines[i]=text_lines[i].replace(' Currency ',' ')
		# if ' Address ' in text_lines[i]:
		if i in address_street:
			text_lines[i]=text_lines[i].replace(' Street ',' ')
		if i in address_primary:
			text_lines[i]=text_lines[i].replace(' primary ',' ')
		if i in address_city:
			text_lines[i]=text_lines[i].replace(' City ',' ')
		if i in address_type:
			text_lines[i]=text_lines[i][0:250].replace(' type ',' ')
		if i in address_state:
			text_lines[i]=text_lines[i].replace(' State ',' ')
		if i in address_country:
			text_lines[i]=text_lines[i].replace(' Country ',' ')
		# if i in address_citycountry:
		# 	text_lines[i]=text_lines[i].replace(' CityCountry ',' ')
		# if ' Phone ' in text_lines[i]:
		if i in phone_primary:
			text_lines[i]=text_lines[i].replace(' primary ',' ')
		if i in phone_type:
			text_lines[i]=text_lines[i][250:].replace(' type ',' ')
		if i in phone_countrycode:
			text_lines[i]=text_lines[i].replace(' CountryCode ',' ')
		if i in phone_areacode:
			text_lines[i]=text_lines[i].replace(' AreaCode ',' ')
		if i in phone_number:
			text_lines[i]=text_lines[i].replace(' Number ',' ')
		# if i in phone_extension:
		# 	text_lines[i]=text_lines[i].replace(' Extension ',' ')
		# if ' Account ' in text_lines[i]:
		if i in account_id:
			text_lines[i]=text_lines[i][30:].replace(' id ',' ')
		if i in account_category:
			text_lines[i]=text_lines[i].replace(' Category ',' ')
		if i in account_accounttile:
			text_lines[i]=text_lines[i].replace(' AccountTitle ',' ')
			# if i in account_shorttitle:
			# 	text_lines[i]=text_lines[i].replace(' ShortTitle ',' ')
		if i in account_mnemonic:
			text_lines[i]=text_lines[i][50:].replace(' Mnemonic ',' ')
		if i in account_currency:
			text_lines[i]=text_lines[i].replace(' Currency ',' ')
			# if i in account_currencymarket:
			# 	text_lines[i]=text_lines[i].replace(' CurrencyMarket ',' ')
			# if i in account_openingdate:
			# 	text_lines[i]=text_lines[i].replace(' OpeningDate ',' ')
			# if i in account_accountofficer:
			# 	text_lines[i]=text_lines[i].replace(' AccountOfficer ',' ')
			# if i in account_lastupdate:
			# 	text_lines[i]=text_lines[i].replace(' LastUpdate ',' ')
			# if i in account_passbook:
			# 	text_lines[i]=text_lines[i].replace(' Passbook ',' ')
			# if i in account_chargeccy:
			# 	text_lines[i]=text_lines[i].replace(' ChargeCcy ',' ')
			# if i in account_interestccy:
			# 	text_lines[i]=text_lines[i].replace(' InterestCcy ',' ')
			# if i in account_allownetting:
			# 	text_lines[i]=text_lines[i].replace(' AllowNetting ',' ')
		with open(filename,'a') as file_object:
			file_object.write(text_lines[i])

if __name__ == '__main__':
	readRDF()