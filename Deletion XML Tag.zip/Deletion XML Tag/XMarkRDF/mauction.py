import random
def readRDF():
	file = open('./bpeauction.xml','r')
	filename = './mauction.xml'
	text_lines = file.readlines()
	item_list = []
	category_list = []
	edge_list = []
	people_list = []
	openauction_list = []
	closedauction_list = []
	for i in range(len(text_lines)):
		if 'item id' in text_lines[i]:
			item_list.append(i)
		if 'category id' in text_lines[i]:
			category_list.append(i)
		if 'edge from' in text_lines[i]:
			edge_list.append(i)
		if 'person id' in text_lines[i]:
			people_list.append(i)
		if 'open_auction id' in text_lines[i]:
			openauction_list.append(i)
		if 'closed_auction seller person'in text_lines[i]:
			closedauction_list.append(i)
	item_id = random.sample(item_list, int(0.2*len(item_list)))
	item_location = random.sample(item_list, int(0.2*len(item_list)))
	item_quantity = random.sample(item_list, int(0.2*len(item_list)))
	item_name = random.sample(item_list, int(0.2*len(item_list)))
	item_payment = random.sample(item_list, int(0.2*len(item_list)))
	item_shipping = random.sample(item_list, int(0.2*len(item_list)))
	item_category = random.sample(item_list, int(0.2*len(item_list)))
	
	category_id = random.sample(category_list, int(0.2*len(category_list)))
	category_name = random.sample(category_list, int(0.2*len(category_list)))

	edge_from = random.sample(edge_list, int(0.2*len(edge_list)))
	edge_to = random.sample(edge_list, int(0.2*len(edge_list)))

	people_id = random.sample(people_list, int(0.2*len(people_list)))
	people_name = random.sample(people_list, int(0.2*len(people_list)))
	people_emailaddress = random.sample(people_list, int(0.2*len(people_list)))
	people_phone = random.sample(people_list, int(0.2*len(people_list)))
	people_homepage = random.sample(people_list, int(0.2*len(people_list)))
	people_currency = random.sample(people_list, int(0.2*len(people_list)))
	people_creditcard = random.sample(people_list, int(0.2*len(people_list)))
	people_street = random.sample(people_list, int(0.2*len(people_list)))
	people_city = random.sample(people_list, int(0.2*len(people_list)))
	people_province = random.sample(people_list, int(0.2*len(people_list)))
	people_zipcode = random.sample(people_list, int(0.2*len(people_list)))
	people_country = random.sample(people_list, int(0.2*len(people_list)))
	people_interest = random.sample(people_list, int(0.2*len(people_list)))
	people_education = random.sample(people_list, int(0.2*len(people_list)))
	people_business = random.sample(people_list, int(0.2*len(people_list)))
	people_age = random.sample(people_list, int(0.2*len(people_list)))
	people_watch = random.sample(people_list, int(0.2*len(people_list)))
	
	openauction_initial = random.sample(openauction_list, int(0.2*len(openauction_list)))
	openauction_date = random.sample(openauction_list, int(0.2*len(openauction_list)))
	openauction_time = random.sample(openauction_list, int(0.2*len(openauction_list)))
	openauction_personref = random.sample(openauction_list, int(0.2*len(openauction_list)))
	openauction_increase = random.sample(openauction_list, int(0.2*len(openauction_list)))
	openauction_current = random.sample(openauction_list, int(0.2*len(openauction_list)))
	openauction_itemref = random.sample(openauction_list, int(0.2*len(openauction_list)))
	openauction_seller = random.sample(openauction_list, int(0.2*len(openauction_list)))
	openauction_start = random.sample(openauction_list, int(0.2*len(openauction_list)))
	openauction_end = random.sample(openauction_list, int(0.2*len(openauction_list)))
	openauction_author = random.sample(openauction_list, int(0.2*len(openauction_list)))
	openauction_happiness = random.sample(openauction_list, int(0.2*len(openauction_list)))

	closedauction_seller = random.sample(closedauction_list, int(0.2*len(closedauction_list)))
	closedauction_buyer = random.sample(closedauction_list, int(0.2*len(closedauction_list)))
	closedauction_itemref = random.sample(closedauction_list, int(0.2*len(closedauction_list)))
	closedauction_price = random.sample(closedauction_list, int(0.2*len(closedauction_list)))
	closedauction_date = random.sample(closedauction_list, int(0.2*len(closedauction_list)))
	closedauction_quantity = random.sample(closedauction_list, int(0.2*len(closedauction_list)))
	closedauction_type = random.sample(closedauction_list, int(0.2*len(closedauction_list)))
	closedauction_author = random.sample(closedauction_list, int(0.2*len(closedauction_list)))
	closedauction_happiness = random.sample(closedauction_list, int(0.2*len(closedauction_list)))
	
	for i in range(len(text_lines)):
		if i in item_id:
			text_lines[i]=text_lines[i].replace(' id ',' ')
		if i in item_location:
			text_lines[i]=text_lines[i].replace(' location ',' ')
		if i in item_quantity:
			text_lines[i]=text_lines[i].replace(' quantity ',' ')
		if i in item_name:
			text_lines[i]=text_lines[i].replace(' name ',' ')
		if i in item_payment:
			text_lines[i]=text_lines[i].replace(' payment ',' ')
		if i in item_shipping:
			text_lines[i]=text_lines[i].replace(' shipping ',' ')
		if i in item_category:
			text_lines[i]=text_lines[i].replace(' category ',' ')

		if i in category_id:
			text_lines[i]=text_lines[i].replace(' id ',' ')
		if i in category_name:
			text_lines[i]=text_lines[i].replace(' name ',' ')
		
		if i in edge_from:
			text_lines[i]=text_lines[i].replace(' from ',' ')
		if i in edge_to:
			text_lines[i]=text_lines[i].replace(' to ',' ')
		
		if i in people_id:
			text_lines[i]=text_lines[i].replace(' id ',' ')
		if i in people_name:
			text_lines[i]=text_lines[i].replace(' name ',' ')
		if i in people_emailaddress:
			text_lines[i]=text_lines[i].replace(' emailaddress ',' ')
		if i in people_phone:
			text_lines[i]=text_lines[i].replace(' phone ',' ')
		if i in people_homepage:
			text_lines[i]=text_lines[i].replace(' homepage ',' ')
		if i in people_currency:
			text_lines[i]=text_lines[i].replace(' currency ',' ')
		if i in people_creditcard:
			text_lines[i]=text_lines[i].replace(' creditcard ',' ')
		if i in people_street:
			text_lines[i]=text_lines[i].replace(' street ',' ')
		if i in people_city:
			text_lines[i]=text_lines[i].replace(' city ',' ')
		if i in people_province:
			text_lines[i]=text_lines[i].replace(' province ',' ')
		if i in people_zipcode:
			text_lines[i]=text_lines[i].replace(' zipcode ',' ')
		if i in people_country:
			text_lines[i]=text_lines[i].replace(' country ',' ')
		if i in people_interest:
			text_lines[i]=text_lines[i].replace(' interest ',' ')
		if i in people_education:
			text_lines[i]=text_lines[i].replace(' education ',' ')
		if i in people_business:
			text_lines[i]=text_lines[i].replace(' business ',' ')
		if i in people_age:
			text_lines[i]=text_lines[i].replace(' age ',' ')
		if i in people_watch:
			text_lines[i]=text_lines[i].replace(' watch ',' ')
		

		if i in openauction_initial:
			text_lines[i]=text_lines[i].replace(' initial ',' ')
		if i in openauction_date:
			text_lines[i]=text_lines[i].replace(' date ',' ')
		if i in openauction_time:
			text_lines[i]=text_lines[i].replace(' time ',' ')
		if i in openauction_personref:
			text_lines[i]=text_lines[i].replace(' personref ',' ')
		if i in openauction_increase:
			text_lines[i]=text_lines[i].replace(' increase ',' ')
		if i in openauction_current:
			text_lines[i]=text_lines[i].replace(' current ',' ')
		if i in openauction_itemref:
			text_lines[i]=text_lines[i].replace(' itemref ',' ')
		if i in openauction_seller:
			text_lines[i]=text_lines[i].replace(' seller ',' ')
		if i in openauction_start:
			text_lines[i]=text_lines[i].replace(' start ',' ')
		if i in openauction_end:
			text_lines[i]=text_lines[i].replace(' end ',' ')
		if i in openauction_author:
			text_lines[i]=text_lines[i].replace(' author ',' ')
		if i in openauction_happiness:
			text_lines[i]=text_lines[i].replace(' happiness ',' ')
		

		if i in closedauction_seller:
			text_lines[i]=text_lines[i].replace(' seller ',' ')
		if i in closedauction_buyer:
			text_lines[i]=text_lines[i].replace(' buyer ',' ')
		if i in closedauction_itemref:
			text_lines[i]=text_lines[i].replace(' itemref ',' ')
		if i in closedauction_price:
			text_lines[i]=text_lines[i].replace(' price ',' ')
		if i in closedauction_date:
			text_lines[i]=text_lines[i].replace(' date ',' ')
		if i in closedauction_quantity:
			text_lines[i]=text_lines[i].replace(' quantity ',' ')
		if i in closedauction_type:
			text_lines[i]=text_lines[i].replace(' type ',' ')
		if i in closedauction_author:
			text_lines[i]=text_lines[i].replace(' author ',' ')
		if i in closedauction_happiness:
			text_lines[i]=text_lines[i].replace(' happiness ',' ')
		with open(filename,'a') as file_object:
			file_object.write(text_lines[i])

if __name__ == '__main__':
	readRDF()